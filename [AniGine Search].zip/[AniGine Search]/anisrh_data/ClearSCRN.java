import java.io.*;

public class ClearSCRN extends AniEngine
{
 public void clrscr() throws IOException, InterruptedException
 {
     new ProcessBuilder("cmd","/c","cls").inheritIO().start().waitFor();
 }
}
         


/*
public class ClearSCRN extends AniEngine
{
    int cl=0;
    public void clrscr()
    {
       for (cl=0;cl<=100;cl++)
       {
           System.out.print("\n");
       }
    }
}
*/