import java.io.*;
import java.util.*;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

public class AnimeList extends AniEngine
{
 int i=0,flag=0,j=0,k=0,fo_nd=0,iz=0,m=1,con=0,configg=0,anict=0,qtc,va=0;
 
 int x=0,y=0,tx=0,z=0,a=0,ur=0;
 int tolani_r=0;
 
 
 String beta;
 String ani_beta;
 String check_beta;
 String[][] anidata;
 String[][] ani_all;
 String lhdal;


 public static String readFile(String path, Charset encoding) throws IOException 
 {
		return Files.readString(Paths.get(path), encoding);
 }


 public AnimeList()
 {
     AnimeDataBase obj_adb=new AnimeDataBase();
     anidata=obj_adb.anime_list_ka_fun();
                
		String filePath = "localdir.ld";

		String content = null;
		try {
			content = readFile(filePath, StandardCharsets.UTF_8);
		} catch (IOException e) {
			e.printStackTrace();
		}
		lhdal=content;
  
 }
 
 
 
 public int tolani()
 {
  if (anidata[0][0]=="")
  {
   tolani_r=0;
  }
  else
  {
   tolani_r=anidata.length;
  }
  return tolani_r;
 }
 

 public int anistckall(String cat_stckall)
 {
  
  m=0;
  
     for (x=0;x<anidata.length;x++)
     {
      for(y=0;y<anidata.length;y++)
      {
         if (anidata[x].length==y)
         {
             break;
         }
         
         ani_beta=anidata[x][y];
         if (ani_beta.equals(cat_stckall))
         {
             m=m+1;
         }
            
      
      }
     }
  return m;
 }
 
 
 public int anistck(String[] cat_stck)
 {
  anict=0;
  m=0;
  qtc=0;

  for (int qx=0;qx<anidata.length;qx++)
  {
   anict=0;
   for (int qc=0;qc<anidata[qx].length;qc++)
   {
    for (int qz=0;qz<cat_stck.length;qz++)
    {
     beta=anidata[qx][qc];
     check_beta=cat_stck[qz];
     if (beta.equals(check_beta))
     {
      anict++;
     }
    }
   }
   if (anict==cat_stck.length)
   {
    m=m+1;
   }
  }

  return m;
 }



 public void anisrch(String[] catgr)throws IOException, InterruptedException
 { 
   i=0;
   flag=0;
   fo_nd=0;
   m=0;
   iz=0;
   configg=0;
   anict=0;
   ur=0;
   int indr=0;
   String strdr;

   AnimeList awq = new AnimeList();
   
   int drptlt=awq.anistck(catgr);

   String[] dry= new String[drptlt];
      
      for (int qx=0;qx<anidata.length;qx++)
      {
       anict=0;
       va=0;
       for (int qc=0;qc<anidata[qx].length;qc++)
       {
        for (int qz=0;qz<catgr.length;qz++)
        {
         beta=anidata[qx][qc];
         check_beta=catgr[qz];
         if (beta.equals(check_beta))
         {
          anict++;
         }
        }
       }
       if (anict==catgr.length)  //&&(!(anidata[qx][0]).equals(null)))
       { 
        String otmp=anidata[qx][0];
        dry[ur]=otmp;
        ur=ur+1;
        fo_nd=1;
         con=con+1;
         if (con<10)
         {
           System.out.print ("\n0"+(con)+"-> "+anidata[qx][0]+" :- ");
         }
         else
         {
           System.out.print ("\n"+(con)+"-> "+anidata[qx][0]+" :- ");
         }
         for (int vb=1;vb<anidata[qx].length;vb++)
         {
          if (vb!=anidata[qx].length-1)
          {
           System.out.print (" "+anidata[qx][vb]+",");
          }
          else
          {
           System.out.print (" "+anidata[qx][vb]);
          }
         }
         //break;
        
       }
      }
      

       System.out.print ("\n");



      Scanner isc = new Scanner(System.in);

      for (;fo_nd!=0;)
      {
       if (fo_nd==0) { break; }
       System.out.print ("\nInput The Anime Number To Watch it <Press Enter(s) to Skip> : ");
       strdr=isc.nextLine();
       if (strdr.length()==0||strdr.equals(null)||strdr=="") { break; }
       int stch=0;
       for (int qt=0;qt<strdr.length();qt++)
       {
        if (Character.isDigit(strdr.charAt(qt)))
        {
        }
        else
        {
         stch=1;
        }
       }
       if (stch==1)
       {
        System.out.print("\nIt was a wrong input!");
        continue;
       }
       else
       {
        indr=Integer.parseInt(strdr);
       }
       
       String tempdr="explorer.exe \""+lhdal;    ///DIR HERE         //String tempdr="explorer.exe \"https://animekaizoku.com/?s=";
       int trw=0;
       for (int qop=0;qop<dry.length;qop++)
       {
        if (indr==(qop+1))
        {
         tempdr=tempdr+"\\"+dry[qop]+"\"";    //+"/"";
         //System.out.print("\n"+tempdr);
         new ProcessBuilder("cmd","/c",tempdr).inheritIO().start().waitFor();
         trw=0;
         break;
        }
        else
        {
         trw=1;
        }
       }
       if (trw==1)
       {
        System.out.print(" It was a wrong input!");
        continue;
       }
      }
           








   if (fo_nd==0)
   {
    ClearSCRN al_crno= new ClearSCRN();
    al_crno.clrscr();
    System.out.print("\t\t\tNo Anime With Such Tag(s) Currnet Available in Stock!!\n\nPress Enter to Continue...");
    System.out.print("\n");
    System.in.read();
   }
   
   if(fo_nd!=0)
   {
    System.in.read();
   }
   System.out.print ("\n");
   
  }
}

