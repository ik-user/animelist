import java.util.*;
import java.io.*;

public class AniEngine
{
    public static void main(String[] args)throws IOException, InterruptedException
    {
        
        AniSearch obje = new AniSearch();
        obje.sarmain();
    }
}
