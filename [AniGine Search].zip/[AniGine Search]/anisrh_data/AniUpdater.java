import java.io.*;
import java.net.*;


public class AniUpdater
{
 public static void main(String[] args)throws IOException, InterruptedException
 {
  URL ik_ani_list = new URL("https://raw.githubusercontent.com/ik-user/animelist/main/ani_source.lst");
  BufferedReader in = new BufferedReader(new InputStreamReader(ik_ani_list.openStream()));
  
  PrintWriter out =new PrintWriter(new FileWriter("ani_source.lst"));
       
       

  String inputLine;
  while ((inputLine = in.readLine()) != null)
  {
   out.print(inputLine+"\n");
  }
  in.close();
  out.close();
 }
}