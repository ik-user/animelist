

import java.util.*;
import java.io.*;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

public class ReadReady extends ListCheck// extends DoneTxt
{
     
     public void anitxtready()throws IOException, InterruptedException
     {
      ReadTextSource qw_ob= new ReadTextSource();
      String s=qw_ob.txtread();
      String[][] fns;
      int lmt=0;
      String su;
      

      String s1[]=s.split("@@@@");
      int lani[]=new int[s1.length];
      String final_anilist[][]= new String[s1.length][s1.length];// change made here
      
      for(int i=0;i<s1.length;i++)
      {
       String single_int[]=s1[i].split("===");
       
       for(int j=0;j<single_int.length;j++)
       {
        final_anilist[i][j]=single_int[j];
       }
      }
      
      
      
      for(int a=0;a<final_anilist.length;a++)
      {
       lani[a]=0;
       for(int b=0;b<final_anilist[a].length;b++)
       {
        if ((final_anilist[a][b])!= null)
        {
         lani[a]=b+1;
        }
       }
      }
      //su=su+"import java.util.*;\nimport java.io.*;\nimport java.nio.charset.Charset;\nimport java.nio.charset.StandardCharsets;\nimport java.nio.file.Files;\nimport java.nio.file.Paths;";
      //su=su+"\n\npublic class DoneTxt extends AnimeDataBase\n{\n public String[][] doneani()\n{";

      //su=su+"\n String[][] fntxt={";
      su="{";
      for(int a=0;a<final_anilist.length;a++)
       {

        for (int b=0;b<lani[a];b++)
        {
            if (b==0)
            {
                su=su+"{\"";
            }
            su=su+final_anilist[a][b];
            if (b<lani[a]-1)
            {
                su=su+"\",\"";
            }
            if (b==lani[a]-1)
            {
                su=su+"\"}";
            }
        }
        su=su+"";
        if (a<final_anilist.length-1)
            {
                su=su+",";
            }
       }
      
       su=su+"};";
       su="import java.util.*;\n\npublic class AnimeDataBase extends AniEngine\n{\npublic String[][] anime_list_ka_fun()\n{\nString anime_ka_list[][]="+su+"\n\nint i=0;\nint j=0;\nString anistr[];\nString anicra,anicrb;\nfor(i=0;i<anime_ka_list.length;i++)\n{\nfor(j=i+1;j<anime_ka_list.length;j++)\n{\nanicra=anime_ka_list[i][0];\nanicrb=anime_ka_list[j][0];\nif (anicra.compareTo(anicrb)>0)\n{\nanistr=anime_ka_list[i];\nanime_ka_list[i]=anime_ka_list[j];\nanime_ka_list[j]=anistr;\n}\n}\n}\nreturn anime_ka_list;\n}\n}";
       //su=su+"\n\n return fntxt;\n}\n}";
       PrintWriter out =new PrintWriter(new FileWriter("AnimeDataBase.java"));//"C:\\Users\\Dhiraj\\abcd.java"
       out.print(su);
       out.close();
       //return su; 
     }
     
}
 