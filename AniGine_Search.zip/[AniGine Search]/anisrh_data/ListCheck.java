import java.util.*;
import java.io.*;


public class ListCheck
{
    public static void main(String[] args)throws IOException, InterruptedException
    {
      ReadReady lstch = new ReadReady();
      lstch.anitxtready();
    }
}
