import java.io.*;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

class MisAni
{
   
   public static String readFile(String path, Charset encoding) throws IOException, InterruptedException
   {
     return Files.readString(Paths.get(path), encoding);
   }

   public static void main(String[] args)throws IOException, InterruptedException
   {
                int con=1;
                new ProcessBuilder("cmd","/c","cls").inheritIO().start().waitFor();

                // Stock
                String an_stk;   
                char c=10,bc=95;
		String filePath = "ani_source.lst";

		String content = null;
		try {
			content = readFile(filePath, StandardCharsets.UTF_8);
		} catch (IOException e) {
			e.printStackTrace();
		}
		an_stk=content.replace(c,bc);
                String[] a_lt=an_stk.split("_");
                String[][] f_lt=new String[a_lt.length][a_lt.length];
                for (int z=0;z<=a_lt.length-1;z++)
                {
                 f_lt[z]=a_lt[z].split("===");
                }


                // To Get Dir
                String an_dr;
                String filePath_dr = "localdir.ld";
                String content_dr = null;

                try {
			content_dr = readFile(filePath_dr, StandardCharsets.UTF_8);
		} catch (IOException e) {
			e.printStackTrace();
		}
                an_dr="DIR /B \""+content_dr+"\\\""+" > mng.txt";
                new ProcessBuilder("cmd","/c",an_dr).inheritIO().start().waitFor();
                System.out.print ("\nScanned, Press Any Key to Process...");
                new ProcessBuilder("cmd","/c","pause >nul").inheritIO().start().waitFor();
                new ProcessBuilder("cmd","/c","cls").inheritIO().start().waitFor();
                System.out.print ("\n\t\t Missing Animes\n\n");
                int fg=0;

                //Your List
                String u_dr;
                String filePath_u = "mng.txt";
                String content_u = null;

                try {
			content_u = readFile(filePath_u, StandardCharsets.UTF_8);
		} catch (IOException e) {
			e.printStackTrace();
		}
                u_dr=content_u;


               for (int i=0;i<=f_lt.length-1;i++)
               {
                if (f_lt[i][0].equals(null) && f_lt[i][0]=="") { continue; }
                if ((u_dr.toLowerCase()).contains((f_lt[i][0]).toLowerCase()))
                {
                 if (u_dr.contains(f_lt[i][0])) { } else { System.out.print ("\n"); if (con>=1 && con<=9) { System.out.print ("0"); } con=con+1; fg=1; System.out.print (con+".> "+f_lt[i][0]+"\t\t ~~> Folder Name Case is DIFFIRENT.!"); }
                }
                else
                {
                 System.out.print ("\n");
                 if (con>=1 && con<=9) { System.out.print ("0"); }
                 System.out.print (con+".> "+f_lt[i][0]);
                 con=con+1;
                 fg=1;
                }
               }


                if (fg==0)
                {
                 new ProcessBuilder("cmd","/c","cls").inheritIO().start().waitFor();
                 System.out.print ("\nNothing Missing....");
                }
                System.out.print ("\n\nPress Any Key TWICE to Exit...");
                new ProcessBuilder("cmd","/c","pause >nul").inheritIO().start().waitFor();
                new ProcessBuilder("cmd","/c","pause >nul").inheritIO().start().waitFor();

    }
}