import java.io.*;
import java.util.*;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;


public class AniSearch extends AniEngine
{

 int ani_stock = 00;
 int aga=0;
 int ts=0;
 int intcho[];
 
 Scanner sc = new Scanner(System.in);
 String tag_cho;
 int tag_cho_flag = 0;
 String[] genr = {"\0","Action","Adventure","Cars","Comedy","Dementia","Demons","Drama","Ecchi","Fantasy","Game","Harem","Hentai","Historical","Horror","Josei","Kids","Magic","Martial Arts","Mecha","Military","Music","Mystery","Parody","Police","Psychological","Romance","Samurai","School","Sci-Fi","Seinen","Shoujo","Shoujo Ai","Shounen","Shounen Ai","Slice of Life","Space","Sports","Super Power","Supernatural","Thriller","Vampire","Yaoi","Yuri"};
 int flag =0,fn_chd=0;
 int i=0,stck_no=0;

 int tag_conf=0;
 int brkr=0;
 public void sarmain()throws IOException, InterruptedException
 {


    ClearSCRN as_crno2= new ClearSCRN();
    
    as_crno2.clrscr();//System.out.println ('\u000C');


    inmainloop:
    do
    {
     aga=0;
     int intcho[];
     ClearSCRN as_crno= new ClearSCRN();
     DateTimeSrc up_date= new DateTimeSrc();
     AnimeList obj_1 = new AnimeList();
     ani_stock =obj_1.tolani();
     tag_cho_flag=0;
     fn_chd=0;
     brkr=0;
     tag_conf=0;
     as_crno.clrscr(); //System.out.println ('\u000C');
     //System.out.println ("\n");
     System.out.println ("\n\n\n\n\n\t\t\t\t\t This Application Was Last Updated On "+up_date.datime());
     System.out.println ("\t\t\t\t\t\t\t\t Anime in stock : "+ani_stock);
     System.out.print ("\n\n\n");
     
     System.out.print ("\t\t\t\t\t\t\t\t    Anime Genres\n\n\n\t\t\t\t\t 01. Action("+obj_1.anistckall(genr[1])+") \t 02. Adventure("+obj_1.anistckall(genr[2])+") \t 03. Cars("+obj_1.anistckall(genr[3])+") \n\t\t\t\t\t 04. Comedy("+obj_1.anistckall(genr[4])+") \t 05. Dementia("+obj_1.anistckall(genr[5])+") \t 06. Demons("+obj_1.anistckall(genr[6])+") \n\t\t\t\t\t 07. Drama("+obj_1.anistckall(genr[7])+") \t\t 08. Ecchi("+obj_1.anistckall(genr[8])+") \t\t 09. Fantasy("+obj_1.anistckall(genr[9])+") \n\t\t\t\t\t 10. Game("+obj_1.anistckall(genr[10])+") \t\t 11. Harem("+obj_1.anistckall(genr[11])+") \t\t 12. Hentai("+obj_1.anistckall(genr[12])+") \n\t\t\t\t\t 13. Historical("+obj_1.anistckall(genr[13])+") \t 14. Horror("+obj_1.anistckall(genr[14])+") \t 15. Josei("+obj_1.anistckall(genr[15])+") \n\t\t\t\t\t 16. Kids("+obj_1.anistckall(genr[16])+") \t\t 17. Magic("+obj_1.anistckall(genr[17])+") \t\t 18. Martial Arts("+obj_1.anistckall(genr[18])+") \n\t\t\t\t\t 19. Mecha("+obj_1.anistckall(genr[19])+") \t\t 20. Military("+obj_1.anistckall(genr[20])+") \t 21. Music("+obj_1.anistckall(genr[21])+") \n\t\t\t\t\t 22. Mystery("+obj_1.anistckall(genr[22])+") \t 23. Parody("+obj_1.anistckall(genr[23])+") \t\t 24. Police("+obj_1.anistckall(genr[24])+") \n\t\t\t\t\t 25. Psychological("+obj_1.anistckall(genr[25])+") \t 26. Romance("+obj_1.anistckall(genr[26])+") \t 27. Samurai("+obj_1.anistckall(genr[27])+") \n\t\t\t\t\t 28. School("+obj_1.anistckall(genr[28])+") \t 29. Sci-Fi("+obj_1.anistckall(genr[29])+") \t 30. Seinen("+obj_1.anistckall(genr[30])+") \n\t\t\t\t\t 31. Shoujo("+obj_1.anistckall(genr[31])+") \t\t 32. Shoujo Ai("+obj_1.anistckall(genr[32])+") \t 33. Shounen("+obj_1.anistckall(genr[33])+") \n\t\t\t\t\t 34. Shounen Ai("+obj_1.anistckall(genr[34])+") \t 35. Slice of Life("+obj_1.anistckall(genr[35])+") \t 36. Space("+obj_1.anistckall(genr[36])+") \n\t\t\t\t\t 37. Sports("+obj_1.anistckall(genr[37])+") \t\t 38. Super Power("+obj_1.anistckall(genr[38])+") \t 39. Supernatural("+obj_1.anistckall(genr[39])+") \n\t\t\t\t\t 40. Thriller("+obj_1.anistckall(genr[40])+") \t 41. Vampire("+obj_1.anistckall(genr[41])+")   \t 42. Yaoi("+obj_1.anistckall(genr[42])+") \n\t\t\t\t\t 43. Yuri("+obj_1.anistckall(genr[43])+")");
     
     System.out.print ("\n\n\t\t\t\t\t Instructions :");
     System.out.print ("\n\t\t\t\t\t > Input any value from 1 to 43");
     System.out.print ("\n\t\t\t\t\t > Any Number of Genres separated by single \",\" (Example 1,2,3)");
     System.out.print ("\n\t\t\t\t\t > For All Anime Names in List, Just Input \"all\" (without \"\")");
     System.out.print ("\n\t\t\t\t\t >         <<< To CLOSE, Input \"exit\" (without \"\") >>>");
     System.out.print ("\n\n\t\t\t\t\t What kind of Anime do you want to watch : ");
     tag_cho = sc.nextLine();
     String teta=tag_cho.trim();
     teta = teta.replaceAll("\\s+","");
     if (teta.equals(","))
     {
      teta="";
     }

     if ((teta.toLowerCase()).equals("exit"))
     {
      as_crno.clrscr();
      brkr=1;
      break;
     }
      

     if (teta==""||teta==null||teta.contains(",,"))
     {
      //as_crno.clrscr();
      //System.out.print ("Follow Instrutions Properly, Press Enter(s)!!!!!!");
      //System.in.read();
      //System.in.read();
      continue;
     }

     if ((teta.toLowerCase()).equals("all"))
     {
      teta=",";
     }

       int stch=0;
       for (int qt=0;qt<teta.length();qt++)
       {
        if (Character.isDigit(teta.charAt(qt))||(teta.charAt(qt))==',')
        {
        }
        else
        {
         stch=1;
        }
       }
       if (stch==1)
       {
        as_crno.clrscr();
        continue;
       }
     

     String[] ingr=teta.split(",");
     int ddg=0;
     for (int qt=0;qt<ingr.length;qt++)
     {
       for (int yt=0;yt<ingr[qt].length();yt++)
       {
        if (Character.isDigit((ingr[qt]).charAt(yt)))
        {
        }
        else
        {
         ddg=1;
        }
       }
     }
     if (ddg==1)
     {
        as_crno.clrscr();
        continue;
     }
     

     String[] instr=Arrays.stream(ingr).filter(Objects::nonNull).toArray(String[]::new);


     intcho = Arrays.asList(instr).stream().mapToInt(Integer::parseInt).toArray();
     Arrays.sort (intcho);

     String[]  stcho_ar=new String[intcho.length];





     for (int zzz=intcho.length-1;zzz>=0;zzz--)
     {
      if (intcho[zzz]<1||intcho[zzz]>43)
      {
       tag_conf=2;
       break;
      }
      else //if (intcho[zzz]>=1&&intcho[zzz]<=43)
      {
        for (int inf=0;inf>=0;inf++)
        {
         if (inf>=intcho.length)
         {
          break;
         }
         else
         {
          stcho_ar[inf]=(genr[intcho[inf]]);
         }
        }
      }
     }


     if (tag_conf==0)
     {
      as_crno.clrscr();
      stck_no=obj_1.anistck(stcho_ar);
      System.out.print("Entered Tags : "+(Arrays.toString(stcho_ar)));
      System.out.print ("\n\n\t\t\t\t\t\t Matching Animes("+stck_no+")\n\n");
      obj_1.anisrch(stcho_ar);
      System.out.print ("\n\nTo Procced, Press Any Key...");
      new ProcessBuilder("cmd","/c","pause >nul").inheritIO().start().waitFor();
      System.out.print ("\n\nPress Any Key to Clear...");
      new ProcessBuilder("cmd","/c","pause >nul").inheritIO().start().waitFor();
      as_crno.clrscr();
     }


     if (tag_conf==2&&tag_cho_flag==0)
     {
      as_crno.clrscr();
      System.out.print ("Wrong Input, Press Any Key To Retry!!!!!!!");
      new ProcessBuilder("cmd","/c","pause >nul").inheritIO().start().waitFor();
     }
    }while (tag_cho_flag==0);
    out:
    if (brkr==1)
    {
     // System.out.println ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"); //System.out.println ('\u000C');
     System.out.print ("Press Any Key To Exit...");
    
     new ProcessBuilder("cmd","/c","pause >nul").inheritIO().start().waitFor();   //Thread.sleep(2000);
     System.out.println ("Bye.");
    }
    System.exit(0);
 }
}

