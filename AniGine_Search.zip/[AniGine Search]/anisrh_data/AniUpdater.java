import java.io.*;
import java.net.*;


public class AniUpdater
{
 public static void main(String[] args)throws IOException, InterruptedException
 {
  URL ik_ani_list = new URL("https://raw.githubusercontent.com/ik-user/animelist/main/ani_source.lst");
  BufferedReader in = new BufferedReader(new InputStreamReader(ik_ani_list.openStream()));
  
  PrintWriter out =new PrintWriter(new FileWriter("ani_source.lst"));
       
  int qw=0;

  String inputLine;
  while ((inputLine = in.readLine()) != null)
  {
   if (qw==0)
   {
    out.print(inputLine);
    qw=1;
   }
   else
   {
    out.print("\n"+inputLine);
   }
  }
  in.close();
  out.close();
 }
}