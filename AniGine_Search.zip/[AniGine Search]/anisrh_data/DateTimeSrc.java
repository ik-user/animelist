
import java.io.File;
import java.util.Date;

public class  DateTimeSrc extends AniSearch{
   public Date datime()
   {
      File file = new File("ani_source.lst");
      Long lastModified = file.lastModified();
      Date date = new Date(lastModified);
      
      return date;
   }
}