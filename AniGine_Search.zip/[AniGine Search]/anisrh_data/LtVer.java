import java.io.*;
import java.net.*;


public class LtVer
{
 public static void main(String[] args)throws IOException, InterruptedException
 {
  URL ani_ver = new URL("https://raw.githubusercontent.com/ik-user/animelist/main/olvr");
  BufferedReader in = new BufferedReader(new InputStreamReader(ani_ver.openStream()));
  
  PrintWriter out =new PrintWriter(new FileWriter("olvr.vrg"));
       
       

  String inputLine;
  while ((inputLine = in.readLine()) != null)
  {
   out.print(inputLine);
  }
  in.close();
  out.close();
 }
}