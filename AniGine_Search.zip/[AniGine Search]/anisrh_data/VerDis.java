import java.io.*;
import java.util.*;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

public class VerDis
{
        public static String readFile(String path, Charset encoding) throws IOException {
		return Files.readString(Paths.get(path), encoding);
	}

	public static void main(String[] args)
	{
                String a;
		String filePath_a = "lhvr.vrg";

		String content_a = null;
		try {
			content_a = readFile(filePath_a, StandardCharsets.UTF_8);
		} catch (IOException e) {
			e.printStackTrace();
		}
		a=content_a;

                String b;
		String filePath_b = "olvr.vrg";

		String content_b = null;
		try {
			content_b = readFile(filePath_b, StandardCharsets.UTF_8);
		} catch (IOException r) {
			r.printStackTrace();
		}
		b=content_b;
                
                 
               System.out.print ("\nApplication Version : "+a);
               System.out.print ("\nLatest App Version : "+b); 
 }
}
