import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

class ReadTextSource extends ReadReady
{

        public static String readFile(String path, Charset encoding) throws IOException {
		return Files.readString(Paths.get(path), encoding);
	}

	public String txtread()
	{
                String a;
                
                char c=10,bc=95;
		String filePath = "ani_source.lst";

		String content = null;
		try {
			content = readFile(filePath, StandardCharsets.UTF_8);
		} catch (IOException e) {
			e.printStackTrace();
		}
		a=content.replace(c,bc);
                //String []t=a.split("_");
                //System.out.print(a);
                return a;
                
	}
}