import java.io.*;
import java.util.*;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

public class LocalDirMaker
{
 public static void main(String[] args)throws IOException, InterruptedException
 {
  String dir;
  Scanner sc = new Scanner(System.in);
  System.out.print ("\n    <<<-- Be Accurate as the Example Given! -->>>");
  System.out.print ("\n          DON'T ENTER LIKE THIS : D:\\Animes\\");
  System.out.print ("\n\n\nEnter Your Animes Directory (ex - D:\\Animes): ");
  dir=sc.nextLine();
  PrintWriter out =new PrintWriter(new FileWriter("localdir.ld"));
  out.print(dir);
  out.close();
  System.out.print("\nLocal Directory Changed!");
  System.in.read();
 }
}
